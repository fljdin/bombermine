package org.bukkit.command;

public interface ConsoleCommandSender extends CommandSender {
}
