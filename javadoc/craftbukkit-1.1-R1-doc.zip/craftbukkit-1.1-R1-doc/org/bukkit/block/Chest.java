package org.bukkit.block;

/**
 * Represents a chest.
 */
public interface Chest extends BlockState, ContainerBlock {}
