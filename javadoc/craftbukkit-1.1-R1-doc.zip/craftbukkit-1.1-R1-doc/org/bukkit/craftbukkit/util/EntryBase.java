package org.bukkit.craftbukkit.util;

public class EntryBase {
    protected long key;

    public EntryBase(long key) {
        this.key = key;
    }
}
