package org.bukkit.entity;

/**
 * Represents an Ender Pearl entity
 */
public interface EnderPearl extends Projectile {

}
