package org.bukkit.entity;

/**
 * Represents a villager NPC
 */
public interface Villager extends NPC {

}
