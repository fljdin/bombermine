package org.bukkit.entity;

/**
 * Represents Falling Sand.
 */
public interface FallingSand extends Entity {}
