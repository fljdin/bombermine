package org.bukkit.entity;

/**
 * Represents a snowman entity
 */
public interface Snowman extends Creature {

}
